import gym

import numpy as np
from IPython.display import clear_output
from time import sleep
import random
import os

env = gym.make("gym_zhed:zhed-v0", filename="levels/level4.txt")

print(env.render())